=== Smartlook Visitor Screen Recording ===
Contributors: Smartsupp
Tags: smartlook, visitor, screen, recording
Requires at least: 3.1
Tested up to: 4.9
Stable tag: 2.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Smartlook records behavior of your visitors. On every website. For free. It's the easiest visitor recording tool.
Smartlook points out UX problems, tells you why visitors leave your website and shows what convinced customers to make a purchase.

**See visitor behavior in a video**
Play video recordings of visitors and see what they actually do on your website. It helps you reveal mistakes and find out what to improve. You see the visitor’s mouse movement, where he clicked and how he handled filling of forms.

**Filter visitors**
Find the important visitors using filters. You can filter visitors who were in shopping basket, pricing or other important pages.

**Share insights with your team**
When you discover bad user experience on your website, simply send a link with the recording to your UX designer or developer, so everyone can see what the issue is.

**Tag your visitors**
You can show customer info in Smartlook to see who is actually browsing your website. Use our API to link customer’s name, email or other info from your system.

Have multiple websites in one acount
You can have an unlimited number of websites under your Smartlook account. You can also get invites to access your clients’ accounts.

**Save time on support**
If your customer claims he wasn't able to finish an order, your support guys can verify what actually happened and forward bugs or UX improvement tips to developers.

**Video:** https://www.youtube.com/watch?v=rEZGn3cZbz0

**FEATURES**

* Single pages support
* AJAX, HTTPS support
* Dynamic pages support
* Mobile devices support
* API access
* Visitor filtering
* Visitor tagging (see name and email of visitor)
* Sharing of recordings through a link
* Multiple websites and users in one account

**Website:** https://www.smartlook.com/

== Installation ==

1. Install Smartlook plugin in WordPress and activate it
2. Create new account or use existing one to login to Smartlook
3. Now Smartlook code is in your website. Go to Smartlook dashboard to see visitors on your website

== Frequently Asked Questions ==

If you have any questions contact us via our chat or write to: support@smartsupp.com

== Screenshots ==

1. Plugin screen
2. Smartlook dashboard

== Changelog ==

= 2.0.1 =
* Share logged in user information in Smartlook JS snippet

= 2.0.0 =
* Refactored whole plugin

= 1.0.2 =
* Header fix

= 1.0.1 =
* Bug fixes

= 1.0.0 =
* Plugin release.
